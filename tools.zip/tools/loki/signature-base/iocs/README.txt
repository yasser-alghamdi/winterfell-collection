Files in this directory will be initialised according to strings in their filename. 

The string "hash" in the filename will initialise the file as hash IOC list.
The string "filename" in the filename will initialise the file as filename IOC list.
The string "c2" in the filename will initialise the file as C2 server IOC list.
